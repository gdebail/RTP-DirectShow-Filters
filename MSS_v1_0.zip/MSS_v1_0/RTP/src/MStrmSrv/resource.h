//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MStrmSrv.rc
//
#define IDI_MStrmSrv                    100
#define IDR_MENU                        101
#define IDD_SESSION                     101
#define IDD_ABOUTBOX                    200
#define IDC_TEXT                        1000
#define ID_FILE_OPENCLIP                40001
#define ID_FILE_EXIT                    40002
#define ID_FILE_PAUSE                   40003
#define ID_FILE_STOP                    40004
#define ID_FILE_CLOSE                   40005
#define ID_FILE_MUTE                    40006
#define ID_FILE_FULLSCREEN              40007
#define ID_FILE_SIZE_NORMAL             40008
#define ID_FILE_SIZE_HALF               40009
#define ID_FILE_SIZE_DOUBLE             40010
#define ID_FILE_SIZE_QUARTER            40011
#define ID_FILE_SIZE_THREEQUARTER       40012
#define ID_HELP_ABOUT                   40014
#define ID_RATE_INCREASE                40020
#define ID_RATE_DECREASE                40021
#define ID_RATE_NORMAL                  40022
#define ID_RATE_DOUBLE                  40023
#define ID_RATE_HALF                    40024
#define ID_SINGLE_STEP                  40025
#define ID_CALLBACK_ENABLE              40026
#define ID_CALLBACK_INCREASEBRIGHTNESS  40027
#define ID_CALLBACK_DECREASEBRIGHTNESS  40028
#define ID_CALLBACK_ENABLECOLOR         40029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40017
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
