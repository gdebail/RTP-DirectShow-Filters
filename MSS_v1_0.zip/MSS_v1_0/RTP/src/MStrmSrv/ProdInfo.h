#define DESCRIPTION "Morgan Streaming Server\0"
#define FILENAME "MStrmSvr.exe\0"
