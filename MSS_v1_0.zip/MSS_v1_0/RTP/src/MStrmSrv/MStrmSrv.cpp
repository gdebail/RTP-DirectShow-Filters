//------------------------------------------------------------------------------
// File: MStrmSrv.cpp
//
// Desc: Morgan Streaming Server - a simple audio/video media file streaming
//       server application (using Morgan RTP Destination Filter).
//
// Copyright (c) 1990-2002 Morgan Multimedia.  All rights reserved.
//------------------------------------------------------------------------------

#include <dshow.h>
#include <commctrl.h>
#include <commdlg.h>
#include <stdio.h>
#include <stdiostr.h>
#include <tchar.h>
#include <atlbase.h>

#include "MStrmSrv.h"
#include "..\RTPDest\RTPDestuids.h"
#include "..\RTPDest\iStrmSes.h"

#include "BasicUsageEnvironment.hh"
#include "RTSPServer.hh"

#include <string.h>
#if defined(__WIN32__) || defined(_WIN32)
#else
#include <unistd.h>
#endif
#include <stdlib.h>

// An application can advertise the existence of its filter graph
// by registering the graph with a global Running Object Table (ROT).
// The GraphEdit application can detect and remotely view the running
// filter graph, allowing you to 'spy' on the graph with GraphEdit.
//
// To enable registration in this sample, define REGISTER_FILTERGRAPH.
//
#define REGISTER_FILTERGRAPH

//
// Global data
//
static unsigned gnInstances = 0;
HWND      ghApp=0;
HMENU     ghMenu=0;
HINSTANCE ghInst=0;
HANDLE ghRTSPServerThread = NULL;
static unsigned SessionIdCounter = 0;

#define UM_CREATEWINDOW WM_USER
#define UM_DESTROYWINDOW WM_USER + 1

class CStreamingServerSession
{
public:
	CStreamingServerSession(HRESULT *phr);
	~CStreamingServerSession();

	TCHAR     m_szFileName[MAX_PATH];
	DWORD     m_dwGraphRegister;
	PLAYSTATE m_psCurrent;
	double    m_PlaybackRate;

	HWND	  m_hWnd;

	// Usage Environment with Task Scheduler
	UsageEnvironment* m_RTPenv;
	char m_exit;
	HANDLE m_hRTPThread;
	DWORD m_RTPThreadId;
	static DWORD WINAPI RTPThread(LPVOID pv);
	HANDLE m_hTasksThread;
	DWORD m_TasksThreadId;
	static DWORD WINAPI TasksThread(LPVOID pv);

	// Morgan RTP Dest DirectShow Filter
	IBaseFilter		*m_pRTPDest;

	// its Streaming Session interfaces
	IStreamingSession *m_pStreamingSession;

	// DirectShow interfaces
	IGraphBuilder	*m_pGB;
	IMediaControl	*m_pMC;
	IMediaEventEx	*m_pME;
	IVideoWindow	*m_pVW;
	IBasicAudio		*m_pBA;
	IBasicVideo		*m_pBV;
	IMediaSeeking	*m_pMS;
	IMediaPosition	*m_pMP;
	IVideoFrameStep	*m_pFS;

	HRESULT OpenClip(const char *szFile);
	void PlayClip();
	void PauseClip();
	void StopClip();
	void CloseClip();
	void CloseInterfaces();

	BOOL GetFrameStepInterface();
	HRESULT StepOneFrame();
	HRESULT StepFrames(int nFramesToStep);

	HRESULT ModifyRate(double dRateAdjust);
	HRESULT SetRate(double dRate);

	HRESULT HandleGraphEvent();

	void UpdateMainTitle();

	static Boolean onRTSPcmd(const char* cmdName,
				const char* urlSuffix,
				const char* cseq,
				void* clientData);
};

UsageEnvironment* g_env;

char g_exit = NULL;

void SessionText(CStreamingServerSession *pSession,const TCHAR *szFormat,...)
{
    TCHAR szBuffer[1024];  // Large buffer for very long filenames (like HTTP)

    // Format the input string
    va_list pArgs;
    va_start(pArgs, szFormat);
    _vstprintf(szBuffer, szFormat, pArgs);
    va_end(pArgs);

	if (!IsWindow(pSession->m_hWnd))
		SendMessage(ghApp, UM_CREATEWINDOW, SessionIdCounter, (LPARAM)pSession);

    // Display a message box with the formatted string
	HWND hEdit = GetDlgItem(pSession->m_hWnd, IDC_TEXT);
	SetFocus(hEdit);
	SendMessage(hEdit, EM_SETSEL,  -1, -1);
	SendMessage(hEdit, EM_REPLACESEL,  0, (LPARAM)szBuffer);
	UpdateWindow(hEdit);
	SetFocus(pSession->m_hWnd);
}

void Msg(CStreamingServerSession *pSession, TCHAR *szFormat, ...)
{
    TCHAR szBuffer[512];  // Large buffer for very long filenames (like HTTP)

    // Format the input string
    va_list pArgs;
    va_start(pArgs, szFormat);
    _vstprintf(szBuffer, szFormat, pArgs);
    va_end(pArgs);

    // Display a message box with the formatted string
	if (pSession)
		SessionText(pSession, "RTSP[%.08X] : %s\r\n",pSession , szBuffer);
	else
		MessageBox(NULL, szBuffer, TEXT("Morgan Streaming Server"), MB_OK);
}

LRESULT CALLBACK SessionDlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPWINDOWPOS lpwp;
	CStreamingServerSession *pSession = (CStreamingServerSession *)GetWindowLong(hWnd, GWL_USERDATA);

    switch (message)
    {
        case WM_INITDIALOG:
			pSession = (CStreamingServerSession *)lParam;
			pSession->m_hWnd = hWnd;
			SetWindowLong(hWnd, GWL_USERDATA, (LONG)pSession);
    	    return TRUE;

        case WM_WINDOWPOSCHANGING:
			lpwp = (LPWINDOWPOS)lParam;
			if (lpwp->cx && lpwp->cy)
			{
				RECT rcParent;
				RECT rcClient;
				GetWindowRect(hWnd, &rcParent);
				GetClientRect(hWnd, &rcClient);
				int x = (rcParent.right - rcParent.left) - (rcClient.right - rcClient.left);
				int y = (rcParent.bottom - rcParent.top) - (rcClient.bottom - rcClient.top);
				SetWindowPos(GetDlgItem(hWnd, IDC_TEXT), 0, 0, 0,
					lpwp->cx - x, lpwp->cy - y, SWP_NOMOVE | SWP_NOZORDER);
			}
			return FALSE;

        case WM_COMMAND:
	        if (wParam == IDOK || wParam == IDCANCEL)
	        {
				PostMessage(GetParent(hWnd), UM_DESTROYWINDOW, 0, (LPARAM)hWnd);
	            return TRUE;
	        }
	        break;
    }
    return FALSE;
}

Boolean CStreamingServerSession::onRTSPcmd(const char* cmdName,
				const char* urlSuffix,
				const char* cseq,
				void* clientData)
{
	if (strcmp(cmdName, "SESSION::NEW") == 0)
	{
		HRESULT hr;
		CStreamingServerSession * pSession = new CStreamingServerSession(&hr);

		if (FAILED(hr))
		{
			if (pSession != NULL)
				pSession->CloseInterfaces();

			return False;
		}

		if (pSession == NULL)
			return False;

		SendMessage(ghApp, UM_CREATEWINDOW, ++SessionIdCounter, (LPARAM)pSession);
		SessionText(pSession, "RTSP[%.08X] : %s %s %s\r\n",pSession , cmdName, urlSuffix, cseq);

		// Begin by setting up our usage environment:
		TaskScheduler* scheduler = BasicTaskScheduler::createNew();
		pSession->m_RTPenv = BasicUsageEnvironment::createNew(*scheduler);

		Boolean multicast = (Boolean)GetPrivateProfileInt("Session", "multicast", 0, "mss.ini");
		if (multicast)
			WritePrivateProfileString("Session", "multicast", "1", "mss.ini");
		else
			WritePrivateProfileString("Session", "multicast", "0", "mss.ini");


		// To stream using "source-specific multicast" (SSM), uncomment the following:
		char destAddrStrMulticast[256] = "";
		GetPrivateProfileString("Session", "mcast_addr", "239.255.42.42", destAddrStrMulticast, sizeof(destAddrStrMulticast), "mss.ini");
		WritePrivateProfileString("Session", "mcast_addr", destAddrStrMulticast, "mss.ini");

		/*
		#define USE_SSM 1
		#ifdef USE_SSM
		= "232.255.42.42";
		#else
		= "239.255.42.42"; // From 239.252.0.0 to 239.255.255.255
		// Note: This is a multicast address.  If you wish to stream using
		// unicast instead, then replace this string with the unicast address
		// of the (single) destination.  (You may also need to make a similar
		// change to the receiver program.)
		#endif
		*/

		ServerMediaSession* serverMediaSession = 
			(ServerMediaSession*)pSession->m_pStreamingSession->CreateMediaSession(
			pSession->m_RTPenv, multicast ? destAddrStrMulticast : cseq);

		new RTSPServer::RTSPSession(*pSession->m_RTPenv, SessionIdCounter,
			  *serverMediaSession, (int)clientData, onRTSPcmd, pSession);

		// Create RTP/RTCP sending and receiving thread
		pSession->m_hRTPThread = CreateThread(NULL,
				0,
				pSession->RTPThread,
				pSession,
				0,
				&pSession->m_RTPThreadId);

		return True;
	}
	
	CStreamingServerSession * pSession = (CStreamingServerSession*)clientData;

try {

	if (cmdName[0] == 0)
		SessionText(pSession, "RTSP[%.08X] : %s", pSession , urlSuffix);
	else
		SessionText(pSession, "RTSP[%.08X] : DO %s %s\r\n", pSession , cmdName, urlSuffix);

	if (strcmp(cmdName, "SESSION::DELETE") == 0)
	{
		pSession->m_pStreamingSession->Close();

		PostMessage(ghApp, UM_DESTROYWINDOW, SessionIdCounter--, (LPARAM)pSession);

		//pSession->m_exit = 1;
		TerminateThread(pSession->m_hTasksThread, 0);

		ExitThread(0);

		return True;
	}
	else if (strcmp(cmdName, "OPTIONS") == 0)
	{
		return True;
	}
	else if (strcmp(cmdName, "DESCRIBE") == 0)
	{
		HRESULT hr;
		JIF(pSession->OpenClip(urlSuffix));

		return pSession->m_pStreamingSession->Open(urlSuffix);
	}
	else if (strcmp(cmdName, "SETUP") == 0)
	{
		pSession->m_pStreamingSession->Setup(urlSuffix);
		return True;
	}
	else if (strcmp(cmdName, "PLAY") == 0)
	{
		pSession->PlayClip();
		pSession->m_pStreamingSession->Play(urlSuffix);

		return True;
	}
	else if (strcmp(cmdName, "PAUSE") == 0)
	{
		pSession->PauseClip();
		return True;
	}
	else if (strcmp(cmdName, "TEARDOWN") == 0)
	{
		pSession->StopClip();
		pSession->CloseClip();
		pSession->m_pStreamingSession->Teardown(urlSuffix);
		return True;
	}
}
catch (...) 
{

#define SAFE_CALL(x) try {x} catch (...) {}

	SAFE_CALL(pSession->CloseClip();)
	SAFE_CALL(pSession->m_pStreamingSession->Teardown("alltracks");)
	SAFE_CALL(pSession->m_pStreamingSession->Close();)

	PostMessage(ghApp, UM_DESTROYWINDOW, SessionIdCounter ? SessionIdCounter-- : 0, (LPARAM)pSession);
	ExitThread(0);
}

	return True;
}

void IMonRelease(IMoniker *&pm) {
    if(pm) {
        pm->Release();
        pm = 0;
    }
}

CStreamingServerSession::CStreamingServerSession(HRESULT *phr) :
	m_dwGraphRegister(0),
	m_psCurrent(Stopped),
	m_PlaybackRate(1.0),
	m_pRTPDest(NULL),
	m_pStreamingSession(NULL),
	m_pGB(NULL),
	m_pMC(NULL),
	m_pME(NULL),
	m_pVW(NULL),
	m_pBA(NULL),
	m_pBV(NULL),
	m_pMS(NULL),
	m_pMP(NULL),
	m_pFS(NULL),
	m_hWnd(NULL)
{
	HRESULT hr = S_FALSE;

    // Reset status variables
    m_psCurrent = Init;
	
	// for JIF and LIF macros
	CStreamingServerSession* pSession = this;

    // Get the interface for DirectShow's GraphBuilder
    LIF(CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, 
                         IID_IGraphBuilder, (void **)&m_pGB));
	 
    if(SUCCEEDED(hr))
    {
		// Create our RTP Dest filter
 		LIF(CoCreateInstance((REFCLSID)CLSID_RTPDest,
							  NULL, CLSCTX_INPROC, (REFIID)IID_IBaseFilter,
							  (void **)&m_pRTPDest));

	    if(SUCCEEDED(hr))
		{
			// Query its StreamingSession interface
			LIF(m_pRTPDest->QueryInterface(IID_IStreamingSession, (LPVOID*)&m_pStreamingSession));
 
			if(SUCCEEDED(hr))
			{
				// Add it to our graph
				LIF(m_pGB->AddFilter(m_pRTPDest, NULL));
				m_pRTPDest->Release();
			}
		}
	}

	*phr = hr;

#define DYNAMIC_AUDIO_COMPRESSION
#ifdef DYNAMIC_AUDIO_COMPRESSION
	// Add an ACM compressor,

	//CHAR szACM[] = "@device:cm:{33D9A761-90C8-11D0-BD43-00A0C911CE86}\\304ACELP.net";
	//CHAR szACM[] = "@device:cm:{33D9A761-90C8-11D0-BD43-00A0C911CE86}\\49GSM 6.10";
	//CHAR szACM[] = "@device:cm:{33D9A761-90C8-11D0-BD43-00A0C911CE86}\\6CCITT A-Law";
	//CHAR szACM[] = "@device:cm:{33D9A761-90C8-11D0-BD43-00A0C911CE86}\\7CCITT u-Law";
	//CHAR szACM[] = "@device:cm:{33D9A761-90C8-11D0-BD43-00A0C911CE86}\\2Microsoft ADPCM";
	CHAR szACM[] = "@device:cm:{33D9A761-90C8-11D0-BD43-00A0C911CE86}\\85MPEG Layer-3";

	WCHAR wszACM[1024];
	MultiByteToWideChar(CP_ACP, 0, szACM, -1, wszACM, NUMELMS(wszACM));

	IBindCtx *lpBC;
	LIF(CreateBindCtx(0, &lpBC));
	if (SUCCEEDED(hr))
	{
		IMoniker *pmACM = NULL;
		DWORD dwEaten;
		LIF(MkParseDisplayName(lpBC, wszACM, &dwEaten,
								&pmACM));
		lpBC->Release();

		if (SUCCEEDED(hr))
		{
			IBaseFilter *pMP3Comp;
			LIF(pmACM->BindToObject(0, 0, IID_IBaseFilter, (void**)&pMP3Comp));

			IMonRelease(pmACM);

			if (SUCCEEDED(hr))
			{
				m_pGB->AddFilter(pMP3Comp, NULL);
				pMP3Comp->Release();
			}
		}
	}
#endif

}

CStreamingServerSession::~CStreamingServerSession()
{
}

DWORD WINAPI CStreamingServerSession::TasksThread(LPVOID pv)
{
  int tp = GetPrivateProfileInt("RTCP", "thread_priority", GetThreadPriority(GetCurrentThread()), "mss.ini");
  SetThreadPriority(GetCurrentThread(), tp);
  char sztp[256];
  sprintf(sztp, "%d", tp);
  WritePrivateProfileString("RTCP", "thread_priority", sztp, "mss.ini");

  CStreamingServerSession* pSession = (CStreamingServerSession*)pv;

  ((BasicTaskScheduler&)pSession->m_RTPenv->taskScheduler()).blockOnAlarms(&pSession->m_exit); // does not return til g_exit != 0

  return 0;
}

DWORD WINAPI CStreamingServerSession::RTPThread(LPVOID pv)
{

  int tp = GetPrivateProfileInt("RTP", "thread_priority", GetThreadPriority(GetCurrentThread()), "mss.ini");
  SetThreadPriority(GetCurrentThread(), tp);
  char sztp[256];
  sprintf(sztp, "%d", tp);
  WritePrivateProfileString("RTP", "thread_priority", sztp, "mss.ini");

  CStreamingServerSession* pSession = (CStreamingServerSession*)pv;

  pSession->m_exit = 0;
  pSession->m_hTasksThread = NULL;
  
  // Create RTP/RTCP sending thread
  pSession->m_hTasksThread = CreateThread(NULL,
		0,
		pSession->TasksThread,
		pSession,
		0,
		&pSession->m_TasksThreadId);

  // We're in the receiving thread
  ((BasicTaskScheduler&)pSession->m_RTPenv->taskScheduler()).blockOnReadSocks(&pSession->m_exit); // does not return til g_exit != 0
  

  //pSession->m_RTPenv->taskScheduler().blockMyself(&pSession->m_exit); // does not return til g_exit != 0

  return 0;
}

HRESULT CStreamingServerSession::OpenClip(const char *szFile)
{
    USES_CONVERSION;
    WCHAR wFile[MAX_PATH];
    HRESULT hr = S_FALSE;

	strcpy(m_szFileName, szFile);

    if(m_szFileName[0] == L'\0')
		return hr;

	char *stream = (char *)&m_szFileName[strlen(m_szFileName)];
	while (*--stream != '/' && stream > m_szFileName);
	stream++;

	// video only
	if (stricmp(stream, "video") == 0)
	{
	  stream--;
	  stream[0] = 0;
	  stream++;
	}

	// audio only
	if (stricmp(stream, "audio") == 0)
	{
	  stream--;
	  stream[0] = 0;
	  stream++;
	}

    // Reset status variables
    m_psCurrent = Stopped;

    // Clear open dialog remnants before calling RenderFile()
    UpdateWindow(ghApp);

    // Convert filename to wide character string
    wcscpy(wFile, T2W(m_szFileName));

    if(m_pGB && m_pRTPDest && m_pStreamingSession)
    {
		// for JIF and LIF macros
		CStreamingServerSession* pSession = this;

        // Have the graph builder construct its the appropriate graph automatically
        JIF(m_pGB->RenderFile(wFile, NULL));

        // QueryInterface for DirectShow interfaces
        JIF(m_pGB->QueryInterface(IID_IMediaControl, (void **)&m_pMC));
        JIF(m_pGB->QueryInterface(IID_IMediaEventEx, (void **)&m_pME));
        JIF(m_pGB->QueryInterface(IID_IMediaSeeking, (void **)&m_pMS));
        JIF(m_pGB->QueryInterface(IID_IMediaPosition, (void **)&m_pMP));

        // Query for video interfaces, which may not be relevant for audio files
        JIF(m_pGB->QueryInterface(IID_IVideoWindow, (void **)&m_pVW));
        JIF(m_pGB->QueryInterface(IID_IBasicVideo, (void **)&m_pBV));

        // Query for audio interfaces, which may not be relevant for video-only files
        JIF(m_pGB->QueryInterface(IID_IBasicAudio, (void **)&m_pBA));

        // Have the graph signal event via window callbacks for performance
        JIF(m_pME->SetNotifyWindow((OAHWND)ghApp, WM_GRAPHNOTIFY, (long)this));

        m_PlaybackRate = 1.0;
        UpdateMainTitle();

#ifdef REGISTER_FILTERGRAPH
        hr = AddGraphToRot(m_pGB, &m_dwGraphRegister);
        if (FAILED(hr))
        {
            Msg(this, TEXT("Failed to register filter graph with ROT!  hr=0x%x"), hr);
            m_dwGraphRegister = 0;
        }
#endif

        //SetFocus(ghApp);
    }

    return hr;
}

void CStreamingServerSession::PlayClip()
{
    if (!m_pMC)
        return;

    if((m_psCurrent == Paused) || (m_psCurrent == Stopped))
    {
        if (SUCCEEDED(m_pMC->Run()))
            m_psCurrent = Running;
    }

    UpdateMainTitle();
}

void CStreamingServerSession::PauseClip()
{
    if (!m_pMC)
        return;

    if((m_psCurrent == Stopped) || (m_psCurrent == Running))
    {
        if (SUCCEEDED(m_pMC->Pause()))
            m_psCurrent = Paused;
    }

    UpdateMainTitle();
}


void CStreamingServerSession::StopClip()
{
    HRESULT hr;

    if ((!m_pMC) || (!m_pMS))
        return;

    // Stop and reset postion to beginning
    if((m_psCurrent == Paused) || (m_psCurrent == Running))
    {
        LONGLONG pos = 0;
        hr = m_pMC->Stop();
        m_psCurrent = Stopped;

        // Seek to the beginning
        hr = m_pMS->SetPositions(&pos, AM_SEEKING_AbsolutePositioning ,
            NULL, AM_SEEKING_NoPositioning);

        // Display the first frame to indicate the reset condition
        hr = m_pMC->Pause();
    }

    UpdateMainTitle();
}

BOOL GetClipFileName(LPTSTR szName)
{
    static OPENFILENAME ofn={0};
    static BOOL bSetInitialDir = FALSE;

    // Reset filename
    *szName = 0;

    // Fill in standard structure fields
    ofn.lStructSize       = sizeof(OPENFILENAME);
    ofn.hwndOwner         = ghApp;
    ofn.lpstrFilter       = NULL;
    ofn.lpstrFilter       = FILE_FILTER_TEXT;
    ofn.lpstrCustomFilter = NULL;
    ofn.nFilterIndex      = 1;
    ofn.lpstrFile         = szName;
    ofn.nMaxFile          = MAX_PATH;
    ofn.lpstrTitle        = TEXT("Open Media File...\0");
    ofn.lpstrFileTitle    = NULL;
    ofn.lpstrDefExt       = TEXT("*\0");
    ofn.Flags             = OFN_FILEMUSTEXIST | OFN_READONLY | OFN_PATHMUSTEXIST;

    // Remember the path of the first selected file
    if (bSetInitialDir == FALSE)
    {
        ofn.lpstrInitialDir = DEFAULT_MEDIA_PATH;
        bSetInitialDir = TRUE;
    }
    else
        ofn.lpstrInitialDir = NULL;

    // Create the standard file open dialog and return its result
    return GetOpenFileName((LPOPENFILENAME)&ofn);
}


void CStreamingServerSession::CloseClip()
{
    HRESULT hr;

    // Stop media playback
    if(m_pMC)
        hr = m_pMC->Stop();

    // Clear global flags
    m_psCurrent = Stopped;

    // Clear file name to allow selection of new file with open dialog
    m_szFileName[0] = L'\0';

    // No current media state
    m_psCurrent = Init;

    // Reset the player window
    RECT rect;
    GetClientRect(ghApp, &rect);
    InvalidateRect(ghApp, &rect, TRUE);

    UpdateMainTitle();
}


void CStreamingServerSession::CloseInterfaces()
{
    HRESULT hr;

    // Disable event callbacks
    if (m_pME)
        hr = m_pME->SetNotifyWindow((OAHWND)NULL, 0, 0);

#ifdef REGISTER_FILTERGRAPH
    if (m_dwGraphRegister)
    {
        RemoveGraphFromRot(m_dwGraphRegister);
        m_dwGraphRegister = 0;
    }
#endif

    // Release and zero DirectShow interfaces
    SAFE_RELEASE(m_pME);
    SAFE_RELEASE(m_pMS);
    SAFE_RELEASE(m_pMP);
    SAFE_RELEASE(m_pMC);
    SAFE_RELEASE(m_pBA);
    SAFE_RELEASE(m_pBV);
    SAFE_RELEASE(m_pVW);
    SAFE_RELEASE(m_pFS);
	SAFE_RELEASE(m_pStreamingSession);
	//SAFE_RELEASE(m_pRTPDest);
    SAFE_RELEASE(m_pGB);

	delete this;
}


#ifdef REGISTER_FILTERGRAPH

HRESULT AddGraphToRot(IUnknown *pUnkGraph, DWORD *pdwRegister) 
{
    IMoniker * pMoniker;
    IRunningObjectTable *pROT;
    if (FAILED(GetRunningObjectTable(0, &pROT))) 
    {
        return E_FAIL;
    }

    WCHAR wsz[128];
    wsprintfW(wsz, L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph, 
              GetCurrentProcessId());

    HRESULT hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr)) 
    {
        hr = pROT->Register(0, pUnkGraph, pMoniker, pdwRegister);
        pMoniker->Release();
    }

    pROT->Release();
    return hr;
}

void RemoveGraphFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;

    if (SUCCEEDED(GetRunningObjectTable(0, &pROT))) 
    {
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

#endif

void CStreamingServerSession::UpdateMainTitle()
{
    TCHAR szTitle[MAX_PATH]={0}, szFile[MAX_PATH]={0};

    // If no file is loaded, just show the application title
    if (m_szFileName[0] == L'\0')
    {
        wsprintf(szTitle, TEXT("%s"), APPLICATIONNAME);
    }

    // Otherwise, show useful information
    else
    {
        // Get file name without full path
        GetFilename(m_szFileName, szFile);

        char szPlaybackRate[16];
        if (m_PlaybackRate == 1.0)
            szPlaybackRate[0] = '\0';
        else
            sprintf(szPlaybackRate, "(Rate:%2.2f)", m_PlaybackRate);

        TCHAR szRate[20];

#ifdef UNICODE
        MultiByteToWideChar(CP_ACP, 0, szPlaybackRate, -1, szRate, 20);
        
#else
        lstrcpy(szRate, szPlaybackRate);
#endif

    }

    SetWindowText(m_hWnd, szFile/*szTitle*/);
}


void GetFilename(TCHAR *pszFull, TCHAR *pszFile)
{
    int nLength;
    TCHAR szPath[MAX_PATH]={0};
    BOOL bSetFilename=FALSE;

    // Strip path and return just the file's name
    _tcscpy(szPath, pszFull);
    nLength = (int) _tcslen(szPath);

    for (int i=nLength-1; i>=0; i--)
    {
        if ((szPath[i] == '\\') || (szPath[i] == '/'))
        {
            szPath[i] = '\0';
            lstrcpy(pszFile, &szPath[i+1]);
            bSetFilename = TRUE;
            break;
        }
    }

    // If there was no path given (just a file name), then
    // just copy the full path to the target path.
    if (!bSetFilename)
        _tcscpy(pszFile, pszFull);
}

//
// Some video renderers support stepping media frame by frame with the
// IVideoFrameStep interface.  See the interface documentation for more
// details on frame stepping.
//
BOOL CStreamingServerSession::GetFrameStepInterface()
{
    HRESULT hr;
    IVideoFrameStep *m_pFSTest = NULL;

    // Get the frame step interface, if supported
    hr = m_pGB->QueryInterface(__uuidof(IVideoFrameStep), (PVOID *)&m_pFSTest);
    if (FAILED(hr))
        return FALSE;

    // Check if this decoder can step
    hr = m_pFSTest->CanStep(0L, NULL);

    if (hr == S_OK)
    {
        m_pFS = m_pFSTest;  // Save interface to global variable for later use
        return TRUE;
    }
    else
    {
        m_pFSTest->Release();
        return FALSE;
    }
}


HRESULT CStreamingServerSession::StepOneFrame()
{
    HRESULT hr=S_OK;

    // If the Frame Stepping interface exists, use it to step one frame
    if (m_pFS)
    {
        // The graph must be paused for frame stepping to work
        if (m_psCurrent != State_Paused)
            PauseClip();

        // Step the requested number of frames, if supported
        hr = m_pFS->Step(1, NULL);
    }

    return hr;
}

HRESULT CStreamingServerSession::StepFrames(int nFramesToStep)
{
    HRESULT hr=S_OK;

    // If the Frame Stepping interface exists, use it to step frames
    if (m_pFS)
    {
        // The renderer may not support frame stepping for more than one
        // frame at a time, so check for support.  S_OK indicates that the
        // renderer can step nFramesToStep successfully.
        if ((hr = m_pFS->CanStep(nFramesToStep, NULL)) == S_OK)
        {
            // The graph must be paused for frame stepping to work
            if (m_psCurrent != State_Paused)
                PauseClip();

            // Step the requested number of frames, if supported
            hr = m_pFS->Step(nFramesToStep, NULL);
        }
    }

    return hr;
}


HRESULT CStreamingServerSession::ModifyRate(double dRateAdjust)
{
    HRESULT hr=S_OK;
    double dRate;

    // If the IMediaPosition interface exists, use it to set rate
    if ((m_pMP) && (dRateAdjust != 0))
    {
		if ((hr = m_pMP->get_Rate(&dRate)) == S_OK)
		{
            // Add current rate to adjustment value
            double dNewRate = dRate + dRateAdjust;
			hr = m_pMP->put_Rate(dNewRate);

            // Save global rate
            if (SUCCEEDED(hr))
            {
                m_PlaybackRate = dNewRate;
                UpdateMainTitle();
            }
		}
    }

    return hr;
}


HRESULT CStreamingServerSession::SetRate(double dRate)
{
    HRESULT hr=S_OK;

    // If the IMediaPosition interface exists, use it to set rate
    if (m_pMP)
    {
	    hr = m_pMP->put_Rate(dRate);

        // Save global rate
        if (SUCCEEDED(hr))
        {
            m_PlaybackRate = dRate;
            UpdateMainTitle();
        }
    }

    return hr;
}


HRESULT CStreamingServerSession::HandleGraphEvent()
{
    LONG evCode, evParam1, evParam2;
    HRESULT hr=S_OK;

    // Make sure that we don't access the media event interface
    // after it has already been released.
    if (!m_pME)
	    return S_OK;

    // Process all queued events
    while(SUCCEEDED(m_pME->GetEvent(&evCode, (LONG_PTR *) &evParam1,
                    (LONG_PTR *) &evParam2, 0)))
    {
        // Free memory associated with callback, since we're not using it
        hr = m_pME->FreeEventParams(evCode, evParam1, evParam2);

        // If this is the end of the clip, reset to beginning
        if(EC_COMPLETE == evCode)
        {
			return hr; // #### DO NOT RESTART CLIP

            LONGLONG pos=0;

            // Reset to first frame of movie
            hr = m_pMS->SetPositions(&pos, AM_SEEKING_AbsolutePositioning ,
                                   NULL, AM_SEEKING_NoPositioning);
            if (FAILED(hr))
            {
                // Some custom filters (like the Windows CE MIDI filter)
                // may not implement seeking interfaces (IMediaSeeking)
                // to allow seeking to the start.  In that case, just stop
                // and restart for the same effect.  This should not be
                // necessary in most cases.
                if (FAILED(hr = m_pMC->Stop()))
                {
                    Msg(this, TEXT("Failed(0x%08lx) to stop media clip!"), hr);
                    break;
                }

                if (FAILED(hr = m_pMC->Run()))
                {
                    Msg(this, TEXT("Failed(0x%08lx) to reset media clip!"), hr);
                    break;
                }
            }
        }
    }

    return hr;
}

LRESULT CALLBACK AboutDlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
    	    return TRUE;

        case WM_COMMAND:
	        if (wParam == IDOK)
	        {
                EndDialog(hWnd, TRUE);
	            return TRUE;
	        }
	        break;
    }
    return FALSE;
}


LRESULT CALLBACK WndMainProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	CStreamingServerSession *pSession = NULL;
	HWND hDlg;

    switch(message)
    {
		case UM_CREATEWINDOW:
			pSession = (CStreamingServerSession *)lParam;
			if (IsWindow(pSession->m_hWnd))
				break;

			hDlg = CreateDialogParam(ghInst, MAKEINTRESOURCE(IDD_SESSION),
                              ghApp,  (DLGPROC) SessionDlgProc, (LPARAM)lParam);
			SetWindowPos(hDlg, NULL, wParam * 16, wParam * 16, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			BringWindowToTop(hDlg);
			break;

		case UM_DESTROYWINDOW:
			pSession = (CStreamingServerSession *)lParam;
			DestroyWindow(pSession->m_hWnd);
			delete &pSession->m_RTPenv->taskScheduler();
			delete pSession->m_RTPenv;
			pSession->CloseInterfaces();
			break;

        case WM_COMMAND:

            switch(wParam)
            { // Menus

                case ID_FILE_EXIT:
                    PostQuitMessage(0);
                    break;

                case ID_HELP_ABOUT:
                    DialogBox(ghInst, MAKEINTRESOURCE(IDD_ABOUTBOX),
                              ghApp,  (DLGPROC) AboutDlgProc);
                    break;

            } // Menus
            break;


        case WM_GRAPHNOTIFY:
			pSession = (CStreamingServerSession *)lParam;
            pSession->HandleGraphEvent();
            break;

        case WM_CLOSE:
            SendMessage(ghApp, WM_COMMAND, ID_FILE_EXIT, 0);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);

    } // Window msgs handling

    return DefWindowProc(hWnd, message, wParam, lParam);
}

DWORD WINAPI RTSPServerThread(LPVOID pv)
{
  // Initialize COM
  if(FAILED(CoInitialize(NULL)))
  {
	Msg(NULL, TEXT("CoInitialize Failed!"));
	exit(1);
  }

#ifdef DEBUG
  AllocConsole();
  SetConsoleTitle("Morgan Streaming Server : stdout/stderr");

  /*HANDLE OutH = GetStdHandle(STD_OUTPUT_HANDLE);
  COORD buffer_size;
  buffer_size.X = 80;  // 80 columns
  buffer_size.Y = 60;  // 45 rows
  SetConsoleScreenBufferSize(OutH, buffer_size);*/
  
  //freopen("conin$", "r", stdin);
  freopen("conout$", "w", stdout);
  freopen("conout$", "w", stderr);
  fprintf(stdout, "stdout: ok\n");
  fprintf(stderr, "stderr: ok\n");

  //stdiostream* myStreamIn = new stdiostream(stdin);
  stdiostream* myStreamOut = new stdiostream(stdout);
  stdiostream* myStreamErr = new stdiostream(stderr);
  //cin = *(myStreamIn);
  cout = *(myStreamOut);
  cerr = *(myStreamErr);

  cout << "cout: ok\n";
  cerr << "cerr: ok\n";

#endif

  // Begin by setting up our usage environment:
  TaskScheduler* scheduler = BasicTaskScheduler::createNew();
  g_env = BasicUsageEnvironment::createNew(*scheduler);

  if (++gnInstances == 1)
  {
	  ServerMediaSession* dummyServerMediaSession = NULL;

	  unsigned short portRTSP = (unsigned short)GetPrivateProfileInt("RTSP", "port", 554, "mss.ini");
	  if (portRTSP == 554)
		WritePrivateProfileString("RTSP", "port", "554", "mss.ini");

	  Port ourPort = portRTSP;

	  RTSPServer* rtspServer
		  = RTSPServer::createNew(*g_env, *dummyServerMediaSession, ourPort, CStreamingServerSession::onRTSPcmd);
	  if (rtspServer == NULL) {
		Msg(NULL, "Failed to create RTSP server: %s",
				g_env->getResultMsg());
		return 0;
	  }

  }

  g_exit = 0;

  int tp = GetPrivateProfileInt("RTSP", "thread_priority", GetThreadPriority(GetCurrentThread()), "mss.ini");
  SetThreadPriority(GetCurrentThread(), tp);
  char sztp[256];
  sprintf(sztp, "%d", tp);
  WritePrivateProfileString("RTSP", "thread_priority", sztp, "mss.ini");


  g_env->taskScheduler().blockMyself(&g_exit); // does not return til g_exit != 0

  // Finished with COM
  CoUninitialize();

  return 0;
}

int PASCAL WinMain(HINSTANCE hInstC, HINSTANCE hInstP, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg={0};
    WNDCLASS wc;
    USES_CONVERSION;

    // Initialize COM
    /*if(FAILED(CoInitialize(NULL)))
    {
        Msg(NULL, TEXT("CoInitialize Failed!"));
        exit(1);
    }*/
/*
    // Was a filename specified on the command line?
    if(lpCmdLine[0] != '\0')
#ifdef UNICODE
        MultiByteToWideChar(CP_ACP, 0, lpCmdLine, -1, m_szFileName, MAX_PATH);       
#else
        lstrcpy(m_szFileName, lpCmdLine);
#endif
*/
    // Register the window class
    ZeroMemory(&wc, sizeof wc);
    wc.lpfnWndProc = WndMainProc;
    ghInst = wc.hInstance = hInstC;
    wc.lpszClassName = CLASSNAME;
    //wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon         = LoadIcon(hInstC, MAKEINTRESOURCE(IDI_MStrmSrv));
    if(!RegisterClass(&wc))
    {
        Msg(NULL, TEXT("RegisterClass Failed! Error=0x%x"), GetLastError());
        CoUninitialize();
        exit(1);
    }

    // Create the main window.  The WS_CLIPCHILDREN style is required.
    ghApp = CreateWindow(CLASSNAME, APPLICATIONNAME,
                    WS_OVERLAPPEDWINDOW | WS_CAPTION | WS_CLIPCHILDREN,
                    CW_USEDEFAULT, CW_USEDEFAULT,
                    CW_USEDEFAULT, CW_USEDEFAULT,
                    0, 0, ghInst, 0);

	ShowWindow(ghApp, nCmdShow);

    if(ghApp)
    {
        // Save menu handle for later use
        ghMenu = GetMenu(ghApp);

		DWORD threadid;
		// Create RTSP Server thread
		ghRTSPServerThread = CreateThread(NULL,
				0,
				RTSPServerThread,
				ghApp,
				0,
				&threadid);

		/*SetThreadPriority(ghRTSPServerThread,
			GetThreadPriority(GetCurrentThread()) - 1);*/

        // Main message loop
        while(GetMessage(&msg,NULL,0,0))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    else
    {
        Msg(NULL, TEXT("Failed to create the main window! Error=0x%x"), GetLastError());
    }

	g_exit = 1;

    // Finished with COM
    //CoUninitialize();

    return (int) msg.wParam;
}


