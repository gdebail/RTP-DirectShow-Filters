//------------------------------------------------------------------------------
// File: MStrmSrv.h
//
// Desc: Morgan Streaming Server - a simple audio/video media file streaming
//       server application (using Morgan RTP Destination Filter).
//
// Copyright (c) 1990-2002 Morgan Multimedia.  All rights reserved.
//------------------------------------------------------------------------------

#include <initguid.h>

#define PAGE_SIZE 0x1000

#define MALLOC(s) VirtualAlloc(NULL, ((s + (PAGE_SIZE - 1)) / PAGE_SIZE) * PAGE_SIZE, MEM_COMMIT, PAGE_READWRITE);
#define FREE(p) VirtualFree(p, 0, MEM_RELEASE);

#include "resource.h"

//
// Function prototypes
//
void GetFilename(TCHAR *pszFull, TCHAR *pszFile);

HRESULT AddGraphToRot(IUnknown *pUnkGraph, DWORD *pdwRegister);
void RemoveGraphFromRot(DWORD pdwRegister);


// File filter for OpenFile dialog
#define FILE_FILTER_TEXT \
    TEXT("Video Files (*.avi; *.qt; *.mov; *.mpg; *.mpeg; *.m1v)\0*.avi; *.qt; *.mov; *.mpg; *.mpeg; *.m1v\0")\
    TEXT("Audio files (*.wav; *.mpa; *.mp2; *.mp3; *.au; *.aif; *.aiff; *.snd)\0*.wav; *.mpa; *.mp2; *.mp3; *.au; *.aif; *.aiff; *.snd\0")\
    TEXT("MIDI Files (*.mid, *.midi, *.rmi)\0*.mid; *.midi; *.rmi\0") \
    TEXT("Image Files (*.jpg, *.bmp, *.gif, *.tga)\0*.jpg; *.bmp; *.gif; *.tga\0") \
    TEXT("All Files (*.*)\0*.*;\0\0")

// Begin default media search at root directory
#define DEFAULT_MEDIA_PATH  TEXT("\\\0")

// Defaults used with audio-only files
#define DEFAULT_AUDIO_WIDTH     240
#define DEFAULT_AUDIO_HEIGHT    120
#define DEFAULT_VIDEO_WIDTH     320
#define DEFAULT_VIDEO_HEIGHT    240
#define MINIMUM_VIDEO_WIDTH     200
#define MINIMUM_VIDEO_HEIGHT    120

#define APPLICATIONNAME TEXT("Morgan Streaming Server")
#define CLASSNAME       TEXT("MStrmSrv")

#define WM_GRAPHNOTIFY  WM_USER+13

enum PLAYSTATE {Stopped, Paused, Running, Init};

//
// Macros
//
#define SAFE_RELEASE(x) { if (x) x->Release(); x = NULL; }

#define JIF(x) if (FAILED(hr=(x))) \
    {Msg(pSession, TEXT("FAILED(hr=0x%x) in ") TEXT(#x), hr); return hr;}

#define LIF(x) if (FAILED(hr=(x))) \
    {Msg(pSession, TEXT("FAILED(hr=0x%x) in ") TEXT(#x), hr);}
