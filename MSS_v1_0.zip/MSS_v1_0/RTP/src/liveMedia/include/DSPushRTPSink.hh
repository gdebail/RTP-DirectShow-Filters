/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2002 Live Networks, Inc.  All rights reserved.
// RTP sink for a common kind of payload format: Those which pack multiple,
// complete codec frames (as many as possible) into each RTP packet.
// C++ header

#ifndef _DS_PUSH_RTP_SINK_HH
#define _DS_PUSH_RTP_SINK_HH

#ifndef _RTP_SINK_HH
#include "RTPSink.hh"
#endif

#include <strmif.h>
#ifndef _SAMPLEPROPS
#define _SAMPLEPROPS
typedef struct _SampleProps {
  REFERENCE_TIME   Start;           /* Start sample time */
  REFERENCE_TIME   End;             /* End sample time */
  LONGLONG         MediaStart;      /* Real media start position */
  LONGLONG         MediaEnd;        /* A difference to get the end */
  BYTE Discontinuity;
  BYTE Preroll;
  BYTE SyncPoint;
  WORD HeaderSize;
  WORD FrameSize;
} SampleProps;
#endif

class DSPushRTPSink: public RTPSink {
public:
  static HRESULT onReceive(void *clientData, AM_MEDIA_TYPE* pMediaType, IMediaSample *pSample);
  virtual unsigned specialHeaderSize() const;
      // returns the size of any special header used (following the RTP header)
  Boolean startPlaying(afterPlayingFunc* afterFunc,
		       void* afterClientData);
  virtual void stopPlaying();
protected:
  DSPushRTPSink(UsageEnvironment& env,
		     Groupsock* rtpgs, unsigned char rtpPayloadType,
		     unsigned rtpTimestampFrequency,
		     char const* rtpPayloadFormatName);
	// we're a virtual base class

  virtual ~DSPushRTPSink();

  virtual void doSpecialFrameHandling(unsigned fragmentationOffset,
				      unsigned char* frameStart,
				      unsigned numBytesInFrame,
				      struct timeval frameTimestamp,
				      unsigned numRemainingBytes,
					  SampleProps* sProps);
      // perform any processing specific to the particular payload format

  // Functions that might be called by doSpecialFrameHandling():
  Boolean isFirstPacket() const { return fIsFirstPacket; }
  void setMarkerBit();
  void setTimestamp(struct timeval timestamp);
  void setSpecialHeaderBytes(unsigned char const* bytes, unsigned numBytes,
			     unsigned bytePosition = 0);

private: // redefined virtual functions:
  virtual Boolean continuePlaying();

  // The following fields are used when we're being played:
  afterPlayingFunc* fAfterFunc;
  void* fAfterClientData;

private:
  HRESULT buildAndSendPackets(AM_MEDIA_TYPE* pMediaType, IMediaSample *pSample);
  void processFrame(unsigned numBytesRead,
			 struct timeval presentationTime,
			 SampleProps* sProps);
  void buildPacket();
  void sendPacket();

  static void sendNext(int firstArg);
  friend void sendNext(int);

  static void ourHandleClosure(void* clientData);

private:
  unsigned char* fSample;
  unsigned char* fPacket;
  unsigned fPacketSize;
  unsigned char* fCurPtr;
  UINT32* fTimestamp;
  unsigned char* fSpecialHeader;
  unsigned fSpecialHeaderSize; // size in bytes of any special header used

  Boolean fIsFirstPacket;
  struct timeval fNextSendTime;

  unsigned fPreferredFrameSize;
  unsigned fPlayTimePerFrame;
  struct timeval fPresentationTime;
  unsigned fLastPlayTime;

};

#endif
