/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2002 Live Networks, Inc.  All rights reserved.
// RTP sink for H.263+ video (RFC 2429)
// C++ header

#ifndef _MS_VIDEO_RTP_SINK_HH
#define _MS_VIDEO_RTP_SINK_HH

//#ifndef _MULTI_FRAMED_RTP_SINK_HH
//#include "MultiFramedRTPSink.hh"
//#endif

#ifndef _DS_PUSH_RTP_SINK_HH
#include "DSPushRTPSink.hh"
#endif

//class MSVideoRTPSink : public MultiFramedRTPSink {
class MSVideoRTPSink : public DSPushRTPSink {
public:
  static MSVideoRTPSink* createNew(UsageEnvironment& env, Groupsock* RTPgs,
				    unsigned char rtpPayloadFormat,
					unsigned rtpTimestampFrequency,
					char const* rtpPayloadFormatName,
					AM_MEDIA_TYPE *pmt);
  static MSVideoRTPSink* createNew(UsageEnvironment& env, Groupsock* RTPgs,
		  AM_MEDIA_TYPE *pmt);
  
protected:
  MSVideoRTPSink(UsageEnvironment& env, Groupsock* RTPgs,
		  unsigned char rtpPayloadFormat,
		  unsigned rtpTimestampFrequency,
		  char const* rtpPayloadFormatName);
	// called only by createNew()

  virtual ~MSVideoRTPSink();

private: // redefined virtual functions:
  virtual void doSpecialFrameHandling(unsigned fragmentationOffset,
                                      unsigned char* frameStart,
                                      unsigned numBytesInFrame,
                                      struct timeval frameTimestamp,
                                      unsigned numRemainingBytes,
									  SampleProps* sProps);
  virtual
  Boolean frameCanAppearAfterPacketStart(unsigned char const* frameStart,
					 unsigned numBytesInFrame) const;
  virtual unsigned specialHeaderSize() const;

  virtual char const* sdpMediaType() const;
public:
  AM_MEDIA_TYPE* fpmt;
  unsigned fHeaderSize;
};

#endif
