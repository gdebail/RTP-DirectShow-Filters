/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2001 Live Networks, Inc.  All rights reserved.
// MS Video RTP Sources
// C++ header

#ifndef _MS_VIDEO_RTP_SOURCE_HH
#define _MS_VIDEO_RTP_SOURCE_HH

#ifndef _MULTI_FRAMED_RTP_SOURCE_HH
#include "MultiFramedRTPSource.hh"
#endif

#include <strmif.h>
#ifndef _SAMPLEPROPS
#define _SAMPLEPROPS
typedef struct _SampleProps {
  REFERENCE_TIME   Start;           /* Start sample time */
  REFERENCE_TIME   End;             /* End sample time */
  LONGLONG         MediaStart;      /* Real media start position */
  LONGLONG         MediaEnd;        /* A difference to get the end */
  BYTE Discontinuity;
  BYTE Preroll;
  BYTE SyncPoint;
  WORD HeaderSize;
  WORD FrameSize;
} SampleProps;
#endif

class MSVideoRTPSource: public MultiFramedRTPSource {
public:
  static MSVideoRTPSource*
  createNew(UsageEnvironment& env, Groupsock* RTPgs,
		char const* mimeTypeString,
	    unsigned char rtpPayloadFormat = 26,
	    unsigned rtpPayloadFrequency = 90000,
		unsigned offset = 0);

  AM_MEDIA_TYPE* fpmt;
  SampleProps* fsProps;

protected:
  virtual ~MSVideoRTPSource();

private:
  MSVideoRTPSource(UsageEnvironment& env, Groupsock* RTPgs,
			 char const* mimeTypeString,
		     unsigned char rtpPayloadFormat,
		     unsigned rtpTimestampFrequency,
			 unsigned offset);
      // called only by createNew()

private:
  // redefined virtual functions:
  virtual Boolean processSpecialHeader(unsigned char* headerStart,
                                       unsigned packetSize,
									   Boolean rtpMarkerBit,
                                       unsigned& resultSpecialHeaderSize);
  virtual char const* MIMEtype() const; 

private:
  char const* fMIMEtypeString;
  unsigned fOffset;
};

#endif
