/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2001 Live Networks, Inc.  All rights reserved.

// MS Video RTP Sources
// Implementation
// 09 26 2002 - Initial Implementation : Giom
// Copyright (c) 1990-2002 Morgan Multimedia  All rights reserved.

#include "MSVideoRTPSource.hh"
#include "GroupsockHelper.hh"

MSVideoRTPSource*
MSVideoRTPSource::createNew(UsageEnvironment& env, Groupsock* RTPgs,
			 char const* mimeTypeString,
		     unsigned char rtpPayloadFormat,
		     unsigned rtpTimestampFrequency,
			 unsigned offset) {
  MSVideoRTPSource* newSource = NULL;

  do {
    newSource = new MSVideoRTPSource(env, RTPgs, 
									mimeTypeString,
									rtpPayloadFormat,
								    rtpTimestampFrequency,
									offset);
    if (newSource == NULL) break;

    // Try to use a big receive buffer for RTP:
    increaseReceiveBufferTo(env, RTPgs->socketNum(), 50*1024);

    return newSource;
  } while (0);

  delete newSource;
  return NULL;
}

MSVideoRTPSource::MSVideoRTPSource(UsageEnvironment& env, Groupsock* RTPgs,
			 char const* mimeTypeString,
		     unsigned char rtpPayloadFormat,
		     unsigned rtpTimestampFrequency,
			 unsigned offset)
  : MultiFramedRTPSource(env, RTPgs,
			 rtpPayloadFormat, rtpTimestampFrequency),
  fMIMEtypeString(strdup(mimeTypeString)), fOffset(offset),
  fpmt(NULL), fsProps(NULL)
{
	fCurrentPacketCompletesFrame = False;
}

MSVideoRTPSource::~MSVideoRTPSource() {

  delete (char *)fMIMEtypeString;

  if (fpmt)
	 delete [] fpmt;

  if (fsProps)
	 delete [] fsProps;

}

Boolean MSVideoRTPSource
::processSpecialHeader(unsigned char* headerStart, unsigned packetSize,
		       Boolean rtpMarkerBit,
		       unsigned& resultSpecialHeaderSize) {
  
	resultSpecialHeaderSize = fOffset;

	if (*(DWORD*)headerStart ==	0x73646976||	// 'vids'
		*(DWORD*)headerStart ==	0x73647561)		// 'auds'
	{
		AM_MEDIA_TYPE* pmt= (AM_MEDIA_TYPE*)headerStart;

		if (fpmt == NULL)
			fpmt = (AM_MEDIA_TYPE*) new BYTE[sizeof(AM_MEDIA_TYPE) + pmt->cbFormat];

		memcpy(fpmt, pmt, sizeof(AM_MEDIA_TYPE) - sizeof(BYTE*));
		fpmt->pbFormat = (BYTE*)(void*)&fpmt->pbFormat + sizeof(BYTE*);
		memcpy(fpmt->pbFormat, &pmt->pbFormat, pmt->cbFormat);

		resultSpecialHeaderSize += sizeof(AM_MEDIA_TYPE) - sizeof(BYTE*) + pmt->cbFormat;

		if (fsProps == NULL)
			fsProps = (SampleProps*) new BYTE[sizeof(SampleProps)];

		memcpy(fsProps, (BYTE*)(void*)&pmt->pbFormat + pmt->cbFormat, sizeof(SampleProps));
		resultSpecialHeaderSize += sizeof(SampleProps);
	}

  // The RTP "M" (marker) bit indicates the last fragment of a frame:
  fCurrentPacketCompletesFrame = rtpMarkerBit;

  return True;
}    

char const* MSVideoRTPSource::MIMEtype() const {
  return fMIMEtypeString;
}
