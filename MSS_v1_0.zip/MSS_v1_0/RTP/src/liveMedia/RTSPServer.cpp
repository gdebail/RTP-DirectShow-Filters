/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2002 Live Networks, Inc.  All rights reserved.
// A RTSP server
// Implementation

#include "RTSPServer.hh"
#include "GroupsockHelper.hh"

#include <string.h>
#if defined(__WIN32__) || defined(_WIN32)
#define _close closesocket
#define snprintf _snprintf
#if defined(_WINNT)
#include <ws2tcpip.h>
#endif
#else
#include <unistd.h>
#include <sys/socket.h>
#include <sys/errno.h>
#define _close close
#endif

////////// RTSPServer //////////

RTSPServer* RTSPServer::createNew(UsageEnvironment& env,
				  ServerMediaSession& serverMediaSession,
				  Port ourPort,
// HACK Giom
		  		  onRTSPFunc* onRTSP) {
// HACK Giom

  int ourSocket = -1;
  RTSPServer* newServer = NULL;

  do {
    int ourSocket = setUpOurSocket(env, ourPort);
    if (ourSocket == -1) break;

// HACK Giom
    RTSPServer* newServer
      = new RTSPServer(env, serverMediaSession, ourSocket);
    if (newServer == NULL) break;

    newServer->fonRTSP = onRTSP;
    
    return newServer;
// HACK Giom
  } while (0);

  if (ourSocket != -1) ::_close(ourSocket);
  delete newServer;
  return NULL;
}

#define LISTEN_BACKLOG_SIZE 20

int RTSPServer::setUpOurSocket(UsageEnvironment& env, Port& ourPort) {
  int ourSocket = -1;

  do {
    ourSocket = setupStreamSocket(env, ourPort, /*Hack Giom*/False);
    if (ourSocket < 0) break;

    // Make sure we have a big send buffer:
    if (!increaseSendBufferTo(env, ourSocket, 50*1024)) break;

    // Allow multiple simultaneous connections:
    if (listen(ourSocket, LISTEN_BACKLOG_SIZE) < 0) {
      env.setResultErrMsg("listen() failed: ");
      break;
    }

    if (ourPort.num() == 0) {
      // bind() will have chosen a port for us; return it also:
      if (!getSourcePort(env, ourSocket, ourPort)) break;
    }

    return ourSocket;
  } while (0);  

  if (ourSocket != -1) ::_close(ourSocket);
  return -1;
}

RTSPServer::RTSPServer(UsageEnvironment& env,
		       ServerMediaSession& serverMediaSession,
		       int ourSocket)
  : Medium(env), fOurServerMediaSession(serverMediaSession),
    fServerSocket(ourSocket), fSessionIdCounter(0) {

  // Arrange to handle connections from others:
  env.taskScheduler().turnOnBackgroundReadHandling(fServerSocket,
        (TaskScheduler::BackgroundHandlerProc*)&incomingConnectionHandler,
						   this);
}

RTSPServer::~RTSPServer() {
  // Turn off background read handling:
  envir().taskScheduler().turnOffBackgroundReadHandling(fServerSocket);

  ::_close(fServerSocket);
}

void RTSPServer::incomingConnectionHandler(void* instance, int /*mask*/) {
  RTSPServer* server = (RTSPServer*)instance;
  server->incomingConnectionHandler1();
}

#define PARAM_STRING_MAX 1024 // HACK Giom 100

void RTSPServer::incomingConnectionHandler1() {
  struct sockaddr_in clientAddr;
  SOCKLEN_T clientAddrLen = sizeof clientAddr;
  int clientSocket = accept(fServerSocket, (struct sockaddr*)&clientAddr,
			    &clientAddrLen);
  if (clientSocket < 0) {
#if defined(__WIN32__) || defined(_WIN32)
    if (WSAGetLastError() != WSAEWOULDBLOCK) {
#else
    if (errno != EWOULDBLOCK) {
#endif
        envir().setResultErrMsg("accept() failed: ");
    }
    return;
  }

  // Create a new object for this RTSP session:
  // (Later, we need to do some garbage collection on sessions that #####
  //  aren't closed down via TEARDOWN) #####

// HACK Giom
  if (fonRTSP)
	  fonRTSP("SESSION::NEW", "", (const char *)our_inet_ntoa(clientAddr.sin_addr), (void *)clientSocket);
  else
	  new RTSPSession(envir(), ++fSessionIdCounter,
		  fOurServerMediaSession, clientSocket);
// HACK Giom

}


////////// RTSPServer::RTSPSession //////////

RTSPServer::RTSPSession
::RTSPSession(UsageEnvironment& env, unsigned sessionId,
	      ServerMediaSession& ourServerMediaSession, int clientSocket,
// HACK Giom
	      onRTSPFunc* onRTSP,
		  void* onRTSPData)
		  : fonRTSP(onRTSP), fonRTSPData(onRTSPData),
// HACK Giom		  
  Medium(env), fOurSessionId(sessionId),
  fOurServerMediaSession(ourServerMediaSession),
  fClientSocket(clientSocket), fSessionIsActive(True) {
  // Arrange to handle incoming requests:
  env.taskScheduler().turnOnBackgroundReadHandling(fClientSocket,
        (TaskScheduler::BackgroundHandlerProc*)&incomingRequestHandler,
						   this);
}

RTSPServer::RTSPSession::~RTSPSession() {
  // Turn off background read handling:
  envir().taskScheduler().turnOffBackgroundReadHandling(fClientSocket);
// HACK Giom
  if (fonRTSP)
	fonRTSP("SESSION::DELETE", "", "", fonRTSPData);
  if(&fOurServerMediaSession != NULL)
	Medium::close(&fOurServerMediaSession);
// HACK Giom
  ::_close(fClientSocket);
}

void RTSPServer::RTSPSession::incomingRequestHandler(void* instance,
						     int /*mask*/) {
  RTSPSession* session = (RTSPSession*)instance;
  session->incomingRequestHandler1();
}

void RTSPServer::RTSPSession::incomingRequestHandler1() {
  struct sockaddr_in fromAddress;

// HACK Giom
  Boolean success = False;
  while (1) {
    unsigned char firstByte;
    if (readSocket(envir(), fClientSocket, &firstByte, 1, fromAddress)
	!= 1) break;
    if (firstByte != '$') {
      // Normal case: This is the start of a regular response; use it:
      fBuffer[0] = firstByte;
      success = True;
      break;
    } else {
      // This is an interleaved packet; read and discard it:
      unsigned char streamChannelId;
      if (readSocket(envir(), fClientSocket, &streamChannelId, 1, fromAddress)
	  != 1) break;

      unsigned short size;
      if (readSocket(envir(), fClientSocket, (unsigned char*)&size, 2,
		     fromAddress) != 2) break;
      size = ntohs(size);

	  fprintf(stderr, "Discarding interleaved RTP or RTCP packet (%d bytes, channel id %d)\n",
		size, streamChannelId);

	  if (size == 0) return;

      unsigned char* tmpBuffer = new unsigned char[size];
      if (tmpBuffer == NULL) break;
      unsigned bytesRead = 0;
      unsigned bytesToRead = size;
      unsigned curBytesRead;
      while ((curBytesRead = readSocket(envir(), fClientSocket,
					&tmpBuffer[bytesRead], bytesToRead,
					fromAddress)) > 0) {
	bytesRead += curBytesRead;
	if (bytesRead >= size) break;
	bytesToRead -= curBytesRead;
      }

	  /*if (fonRTSP)
		fonRTSP("", (const char *)tmpBuffer, "", fonRTSPData);*/

      delete tmpBuffer;
      if (bytesRead != size) break;

      success = True;
    }
  }

  unsigned bytesRead = 0;
  if (success)
   bytesRead = readSocket(envir(), fClientSocket,
				  &fBuffer[1], sizeof fBuffer, fromAddress) + 1;
// HACK Giom
  
// HACK Giom
  fBuffer[bytesRead] = 0;
// HACK Giom
#ifdef DEBUG
  fprintf(stderr, "RTSPSession[%p]::incomingRequestHandler1() read %d bytes:%s\n", this, bytesRead, fBuffer);
#endif
  if (fonRTSP)
	fonRTSP("", (const char *)fBuffer, "", fonRTSPData);
  //  if (bytesRead == 0) return;

  // Parse the request string into command name and 'CSeq',
  // then handle the command:
  char cmdName[PARAM_STRING_MAX] /* HACK Giom */ = "";
  char urlSuffix[PARAM_STRING_MAX] /* HACK Giom */ = "";
  char cseq[PARAM_STRING_MAX] /* HACK Giom */ = "";

// HACK Giom
  Boolean parseOk = parseRequestString((char*)fBuffer, bytesRead,
			  cmdName, sizeof cmdName,
			  urlSuffix, sizeof urlSuffix,
			  cseq, sizeof cseq);

  if (!parseOk) {
    if (fonRTSP)
	  fonRTSP(cmdName, urlSuffix, cseq, fonRTSPData);
// HACK Giom
#ifdef DEBUG
    fprintf(stderr, "parse failed!\n");
#endif
    if (fonRTSP)
	  fonRTSP("", (const char *)"parse failed!", "", fonRTSPData);

    handleCmd_bad(cseq);
  } else if (strcmp(cmdName, "OPTIONS") == 0) {
        if (fonRTSP)
	  fonRTSP(cmdName, urlSuffix, cseq, fonRTSPData);
    handleCmd_OPTIONS(cseq);
  } else if (strcmp(cmdName, "DESCRIBE") == 0) {
    if (fonRTSP)
	  if(fonRTSP(cmdName, urlSuffix, cseq, fonRTSPData))
		handleCmd_DESCRIBE(cseq);
	  else
		sprintf((char*)fBuffer, "RTSP/1.0 404 Not Found\r\nCSeq: %s\r\n\r\n",
			cseq);
	else
    handleCmd_DESCRIBE(cseq);
  } else if (strcmp(cmdName, "SETUP") == 0
	     || strcmp(cmdName, "TEARDOWN") == 0
	     || strcmp(cmdName, "PLAY") == 0) {
    handleCmd_subsession(cmdName, urlSuffix, cseq);
  } else {
    if (fonRTSP)
	  fonRTSP(cmdName, urlSuffix, cseq, fonRTSPData);
    handleCmd_notSupported(cseq);
  }
    
#ifdef DEBUG
  fprintf(stderr, "sending response: %s", fBuffer);
#endif
  if (fonRTSP)
	fonRTSP("", (const char *)fBuffer, "", fonRTSPData);

  int nb = strlen((char*)fBuffer);
  send(fClientSocket, (char const*)fBuffer, strlen((char*)fBuffer), 0);

  if (!fSessionIsActive) delete this;
}

// Handler routines for specific RTSP commands:

static char const* allowedCommandNames
  = "OPTIONS, DESCRIBE, SETUP, TEARDOWN, PLAY";

void RTSPServer::RTSPSession::handleCmd_bad(char const* /*cseq*/) {
  // Don't do anything with "cseq", because it might be nonsense
  sprintf((char*)fBuffer, "RTSP/1.0 400 Bad Request\r\nAllow: %s\r\n\r\n",
	  allowedCommandNames);
  fSessionIsActive = False; // triggers deletion of ourself after responding
}

void RTSPServer::RTSPSession::handleCmd_notSupported(char const* cseq) {
  sprintf((char*)fBuffer, "RTSP/1.0 405 Method Not Allowed\r\nCSeq: %s\r\nAllow: %s\r\n\r\n",
	  cseq, allowedCommandNames);
  fSessionIsActive = False; // triggers deletion of ourself after responding
}

void RTSPServer::RTSPSession::handleCmd_OPTIONS(char const* cseq) {
  sprintf((char*)fBuffer, "RTSP/1.0 200 OK\r\nCSeq: %s\r\nPublic: %s\r\n\r\n",
	  cseq, allowedCommandNames);
}

void RTSPServer::RTSPSession::handleCmd_DESCRIBE(char const* cseq) {
  // We should really check that the request contains an "Accept:" #####
  // for "application/sdp", because that's what we're sending back #####

  // Begin by assembling a basic SDP description for this session:
  char const* sdpDescription
    = fOurServerMediaSession.generateSDPDescription();
  unsigned sdpDescriptionSize = strlen(sdpDescription);
  if (sdpDescriptionSize > sizeof(fBuffer) - 200) { // sanity check
    sprintf((char*)fBuffer, "RTSP/1.0 500 Internal Server Error\r\nCSeq: %s\r\n\r\n",
	    cseq);
    return;
  }
  
  sprintf((char*)fBuffer, "RTSP/1.0 200 OK\r\nCSeq: %s\r\nContent-Type: application/sdp\r\nContent-Length: %d\r\n\r\n%s",
	  cseq, sdpDescriptionSize, sdpDescription);
}

void RTSPServer::RTSPSession
  ::handleCmd_subsession(char const* cmdName,
			 char const* urlSuffix, char const* cseq) {
  // Look up the media subsession whose track id is "urlSuffix":
  ServerMediaSubsessionIterator iter(fOurServerMediaSession);
  ServerMediaSubsession* subsession;
// HACK Giom
  const char *trackId = &urlSuffix[strlen(urlSuffix)];
  while (*--trackId != '/' && trackId > urlSuffix);
  trackId++;
  while ((subsession = iter.next()) != NULL) {
    if (strcmp(subsession->trackId(), trackId) == 0) break; // success
// HACK Giom
  }

  if (subsession == NULL && strcmp(cmdName, "SETUP") == 0) {
    // The specified track id doesn't exist, so this request fails:
    sprintf((char*)fBuffer, "RTSP/1.0 404 Not Found\r\nCSeq: %s\r\n\r\n",
	    cseq);
    return;
  }

  if (fonRTSP)
    fonRTSP(cmdName, trackId, cseq, fonRTSPData);

  // Hack Giom
  ///*
  envir().taskScheduler().turnOffBackgroundReadHandling(fClientSocket);
  envir().taskScheduler().turnOnBackgroundReadHandling(fClientSocket,
		(TaskScheduler::BackgroundHandlerProc*)&incomingRequestHandler,
						   this);
  //*/
  // Hack Giom
  
  if (strcmp(cmdName, "SETUP") == 0) {
    handleCmd_SETUP(subsession, cseq);
  } else if (strcmp(cmdName, "TEARDOWN") == 0) {
    handleCmd_TEARDOWN(subsession, cseq);
  } else if (strcmp(cmdName, "PLAY") == 0) {
    handleCmd_PLAY(subsession, cseq);
  }
}

static char* getLine(char* startOfLine) {
  // returns the start of the next line, or NULL if none
  for (char* ptr = startOfLine; *ptr != '\0'; ++ptr) {
    if (*ptr == '\r' || *ptr == '\n') {
      // We found the end of the line
      *ptr++ = '\0';
      if (*ptr == '\n') ++ptr;
      return ptr;
    }
  }

  return NULL;
}

void RTSPServer::RTSPSession
  ::handleCmd_SETUP(ServerMediaSubsession* subsession, char const* cseq) {
  GroupEId const& groupEId = subsession->groupEId();

// HACK Giom
  Boolean foundClientPortNum = False;
  Boolean foundChannelIds = False;
  unsigned short clientRTPPortNum, clientRTCPPortNum;
  unsigned short rtpCid, rtcpCid;

  char* line = getLine((char*)fBuffer);
  while (line != NULL)
  {
	  // First, check for "Transport:"
	  if (strncmp(line, "Transport: ", 11) == 0)
	  {
		  line += 11;

		  // Then, run through each of the fields, looking for ones we handle:
		  char const* fields = line;
		  char* field = strdup(fields);
		  while (sscanf(fields, "%[^;]", field) == 1) {
			if (sscanf(field, "client_port=%hu-%hu", &clientRTPPortNum, &clientRTCPPortNum) == 1) {
			  foundClientPortNum = True;
			} else if (sscanf(field, "interleaved=%hu-%hu", &rtpCid, &rtcpCid) == 2) {
			  foundChannelIds = True;
			}

			// (Later, do more extensive checking on the "Transport: " hdr #####)

			fields += strlen(field);
			if (fields[0] == '\0') break;
			++fields; // skip over the ';'
		  }
		  delete field;
	  }
	  line = getLine(line);
  }

  char transportTypeString[255];
  if (IsMulticastAddress(groupEId.groupAddress().s_addr))
  {
	  strcpy((char*)transportTypeString, ";multicast");
  }
  else
  {
	  if (foundChannelIds)
	  {
		  if (subsession->rtpSink() != NULL)
			  subsession->rtpSink()->setStreamSocket(fClientSocket, (unsigned char)rtpCid);

		  if (subsession->rtcpInstance() != NULL)
			  subsession->rtcpInstance()->setStreamSocket(fClientSocket, (unsigned char)rtcpCid);

		  sprintf((char*)transportTypeString, "/TCP;unicast;interleaved=%hu-%hu",
			  rtpCid, rtcpCid);
	  }
	  else
	  {
		  strcpy((char*)transportTypeString, ";unicast");
	  }
  }

  char portString[255];
  if (IsMulticastAddress(groupEId.groupAddress().s_addr))
  {
	  sprintf((char*)portString, ";port=%d;ttl=%d", groupEId.portNum(), groupEId.scope().ttl());
  }
  else
  {
	  if (foundClientPortNum)
	  {
		  sprintf((char*)portString, ";server_port=%hu", //-%hu",
			  clientRTPPortNum); //, clientRTCPPortNum);
	  }
	  else
	  {
		  sprintf((char*)portString, ";server_port=%hu", //-%hu",
			  groupEId.portNum()); //, groupEId.portNum() + 1);
	  }
  }

  sprintf((char*)fBuffer, "RTSP/1.0 200 OK\r\nCSeq: %s\r\nTransport: RTP/AVP%s;destination=%s%s\r\nSession: %d\r\n\r\n",
	  cseq, transportTypeString, our_inet_ntoa(groupEId.groupAddress()),
	  portString, fOurSessionId);
// HACK Giom

}

void RTSPServer::RTSPSession
  ::handleCmd_TEARDOWN(ServerMediaSubsession* /*subsession*/,
		       char const* cseq) {
  // We should really check that the supplied "Session:" parameter #####
  // matches us #####
  sprintf((char*)fBuffer, "RTSP/1.0 200 OK\r\nCSeq: %s\r\n\r\n", cseq);
  fSessionIsActive = False; // triggers deletion of ourself after responding
}

void RTSPServer::RTSPSession
  ::handleCmd_PLAY(ServerMediaSubsession* /*subsession*/,
		   char const* cseq) {
  // We should really check that the supplied "Session:" parameter #####
  // matches us #####
  sprintf((char*)fBuffer, "RTSP/1.0 200 OK\r\nCSeq: %s\r\nSession: %d\r\n\r\n",
	  cseq, fOurSessionId);
}

Boolean
RTSPServer::RTSPSession
  ::parseRequestString(char const* reqStr,
		       unsigned reqStrSize,
		       char* resultCmdName,
		       unsigned resultCmdNameMaxSize,
		       char* resultURLSuffix,
		       unsigned resultURLSuffixMaxSize,
		       char* resultCSeq,
		       unsigned resultCSeqMaxSize) {
  // This parser is currently rather dumb; it should be made smarter #####

  // Read everything up to the first space as the command name:
  Boolean parseSucceeded = False;
  unsigned i;
  for (i = 0; i < resultCmdNameMaxSize-1 && i < reqStrSize; ++i) {
    char c = reqStr[i];
    if (c == ' ') {
      parseSucceeded = True;
      break;
    }

    resultCmdName[i] = c;
  }
  resultCmdName[i] = '\0';
  if (!parseSucceeded) return False;
      
  // Look for the URL suffix (between "/" and " RTSP/"):
  parseSucceeded = False;
  /*for (unsigned k = i+1; k < reqStrSize-6; ++k) {
    if (reqStr[k] == ' ' && reqStr[k+1] == 'R' && reqStr[k+2] == 'T' &&
	reqStr[k+3] == 'S' && reqStr[k+4] == 'P' && reqStr[k+5] == '/') {
      while (reqStr[k] == ' ') --k; // skip over all spaces
      unsigned k1 = k;
      while (reqStr[k1] != '/' && reqStr[k1] != ' ') --k1;
      ++k1; // the URL suffix comes from [k1,k]
      if (k - k1 +2 > resultURLSuffixMaxSize) return False; // no space

      parseSucceeded = True;
      unsigned n = 0;
      while (k1 <= k) resultURLSuffix[n++] = reqStr[k1++];
      resultURLSuffix[n] = '\0';
      i = k + 7;
      break;
    }
  }*/
// HACK Giom
  for (unsigned k = i+1; k < reqStrSize-6; ++k) {
    if (reqStr[k] == ' ' && reqStr[k+1] == 'R' && reqStr[k+2] == 'T' &&
	reqStr[k+3] == 'S' && reqStr[k+4] == 'P' && reqStr[k+5] == '/') {
      while (reqStr[k] == ' ') --k; // skip over all spaces
      unsigned k1 = k;
	  // look backward for "//"
      while (*(WORD *)(&reqStr[k1]) != (WORD)0x2F2F && k1 > i) --k1;
	  if (*(WORD *)(&reqStr[k1]) != (WORD)0x2F2F)
	  {
		  // "//" not found ...
		  k1 = k;
		  // look backward for ' '
		  while (reqStr[k1] != ' ') --k1;
		  ++k1;
	  }
	  else
	  {
		// skip "//"
		k1 += 2;

		// look forward for '/' or ' '
	    while (reqStr[k1] != '/' && reqStr[k1] != ' ') ++k1;
		++k1;
        while (reqStr[k1] == '"') ++k1; // skip over all "
	  }

      if (k - k1 +2 > resultURLSuffixMaxSize) return False; // no space

      parseSucceeded = True;
      unsigned n = 0;
      while (k1 <= k) resultURLSuffix[n++] = reqStr[k1++];
      resultURLSuffix[n] = '\0';
      i = k + 7;
      break;
    }
  }
  if (!parseSucceeded) return False;
// HACK Giom

  // Look for "CSeq: ", then read everything up to the next \r as 'CSeq':
  parseSucceeded = False;
  for (unsigned j = i; j < reqStrSize-6; ++j) {
    if (reqStr[j] == 'C' && reqStr[j+1] == 'S' && reqStr[j+2] == 'e' &&
	reqStr[j+3] == 'q' && reqStr[j+4] == ':' && reqStr[j+5] == ' ') {
      j += 6;
      unsigned n;
      for (n = 0; n < resultCSeqMaxSize-1 && j < reqStrSize; ++n,++j) {
	char c = reqStr[j];
	if (c == '\r' || c == '\n') {
	  parseSucceeded = True;
	  break;
	}

	resultCSeq[n] = c;
      }
      resultCSeq[n] = '\0';
      break;
    }
  }
  if (!parseSucceeded) return False;

  return True;
}
