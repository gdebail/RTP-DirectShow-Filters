/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2002 Live Networks, Inc.  All rights reserved.
// RTP sink for a common kind of payload format: Those which pack multiple,
// complete codec frames (as many as possible) into each RTP packet.
// Implementation

#include "DSPushRTPSink.hh"
#include "GroupsockHelper.hh"
#include "BasicUsageEnvironment.hh"

////////// DSPushRTPSink //////////

static unsigned const maxPacketSize = 1450;
	// bytes (1500, minus some allowance for IP, UDP, UMTP headers)
static unsigned const preferredPacketSize = 1000; // bytes
static unsigned const rtpHeaderSize = 12; // later allow for RTP extension header!

DSPushRTPSink::DSPushRTPSink(UsageEnvironment& env,
				       Groupsock* rtpGS,
				       unsigned char rtpPayloadType,
				       unsigned rtpTimestampFrequency,
				       char const* rtpPayloadFormatName)
  : RTPSink(env, rtpGS, rtpPayloadType, rtpTimestampFrequency,
	    rtpPayloadFormatName),
  fIsFirstPacket(True),
  fPreferredFrameSize(0),
  fPlayTimePerFrame(0),
  fLastPlayTime(0) {

  fPresentationTime.tv_sec = 0;
  fPresentationTime.tv_usec = 0;

}

DSPushRTPSink::~DSPushRTPSink() {
}

void DSPushRTPSink
::doSpecialFrameHandling(unsigned /*fragmentationOffset*/,
			 unsigned char* /*frameStart*/,
			 unsigned /*numBytesInFrame*/,
			 struct timeval frameTimestamp,
			 unsigned /*numRemainingBytes*/,
			 SampleProps* /*sProps*/) {
   setTimestamp(frameTimestamp);
}

unsigned DSPushRTPSink::specialHeaderSize() const {
  // default implementation: Assume no special header:
  return 0;
}

void DSPushRTPSink::setMarkerBit() {
  *(UINT32*)fPacket |= htonl(0x00800000);
}

void DSPushRTPSink::setTimestamp(struct timeval timestamp) {
  // First, convert the timestamp to a 32-bit RTP timestamp:
  fCurrentTimestamp = convertToRTPTimestamp(timestamp);

  // Then, insert it into the RTP packet:
  *fTimestamp = htonl(fCurrentTimestamp);
}

void DSPushRTPSink::setSpecialHeaderBytes(unsigned char const* bytes,
					       unsigned numBytes,
					       unsigned bytePosition) {
  // Insert it into the RTP packet:
  memmove(fSpecialHeader + bytePosition, bytes, numBytes);
}

#ifdef BSD
static struct timezone Idunno;
#else
static int Idunno;
#endif

Boolean DSPushRTPSink::startPlaying(afterPlayingFunc* afterFunc,
				void* afterClientData) {
  fAfterFunc = afterFunc;
  fAfterClientData = afterClientData;
  return continuePlaying();
}

Boolean DSPushRTPSink::continuePlaying() {
  return True;
}

void DSPushRTPSink::stopPlaying() {
}

HRESULT DSPushRTPSink::onReceive(void *clientData, AM_MEDIA_TYPE* pMediaType, IMediaSample *pSample)
{
  DSPushRTPSink* sink = (DSPushRTPSink*)clientData;
  return sink ? sink->buildAndSendPackets(pMediaType, pSample) : S_FALSE;
}

HRESULT DSPushRTPSink::buildAndSendPackets(AM_MEDIA_TYPE* pMediaType, IMediaSample *pSample)
{
  fIsFirstPacket = True;

  unsigned fFrameSize = (unsigned)pSample->GetActualDataLength();
  unsigned fHeaderSize = rtpHeaderSize + specialHeaderSize();
/*
  if (*(DWORD*)pMediaType == 0x73646976) //  video
  {
#define MX_SIZE 32 * 1024
	if (fFrameSize > MX_SIZE)
		fFrameSize = MX_SIZE;
  }
*/
  // DShow Sample data
  BYTE *pData;
  pSample->GetPointer(&pData);
  /*
  fSample = pData;
  fPacket = fSample - fHeaderSize;*/

  BYTE *pBuffer = new BYTE[fFrameSize + fHeaderSize];
  fPacket = pBuffer;
  fSample = &pBuffer[fHeaderSize];
  memcpy(fSample, pData, fFrameSize);

  // DShow Sample presentation time
  SampleProps sProps;
  sProps.HeaderSize = fHeaderSize - rtpHeaderSize;
  sProps.FrameSize = fFrameSize;

  if (FAILED(pSample->GetTime(&sProps.Start, &sProps.End)))
  {
	  sProps.Start = sProps.End = (REFERENCE_TIME)-1;
  }
  if (FAILED(pSample->GetMediaTime(&sProps.MediaStart, &sProps.MediaEnd)))
  {
	  sProps.MediaStart = sProps.MediaEnd = (LONGLONG)-1;
  }
  sProps.Discontinuity = pSample->IsDiscontinuity() == S_OK;
  sProps.Preroll = pSample->IsPreroll() == S_OK;
  sProps.SyncPoint = pSample->IsSyncPoint() == S_OK;

  // DShow Sample's presentation time
  if (sProps.Start != (REFERENCE_TIME)-1)
  {
	fPreferredFrameSize = fFrameSize;
	fPlayTimePerFrame = (unsigned)((sProps.End - sProps.Start) / 10);
  }

  // Set the 'presentation time':
  if (fPlayTimePerFrame > 0 && fPreferredFrameSize > 0) {
    if (fPresentationTime.tv_sec == 0 && fPresentationTime.tv_usec == 0) {
      // This is the first frame, so use the current time:
      gettimeofday(&fPresentationTime, &Idunno);
    } else {
      // Increment by the play time of the previous data:
      unsigned uSeconds	= fPresentationTime.tv_usec + fLastPlayTime;
      fPresentationTime.tv_sec += uSeconds/1000000;
      fPresentationTime.tv_usec = uSeconds%1000000;
    }

    // Remember the play time of this data:
    fLastPlayTime = (fPlayTimePerFrame*fFrameSize)/fPreferredFrameSize;
  } else {
    // We don't know a specific play time duration for this data,
    // so just record the current time as being the 'presentation time':
    gettimeofday(&fPresentationTime, &Idunno);
  }

  processFrame(fFrameSize, fPresentationTime, &sProps);

  delete [] pBuffer;

  return S_OK;
}

void DSPushRTPSink::buildPacket() {
  
  fCurPtr = fPacket;
  // Set up the RTP header:
  UINT32 rtpHdr = 0x80000000; // RTP version 2
  rtpHdr |= (fRTPPayloadType<<16);
  rtpHdr |= fSeqNo; // sequence number
  *(UINT32*)fCurPtr = htonl(rtpHdr);
  fCurPtr += 4;

  // Note where the RTP timestamp will go.
  // (We can't fill this in until we start packing payload frames.)
  fTimestamp = (UINT32*)fCurPtr;
  fCurPtr += 4; // leave a hole for the timestamp

  *(UINT32*)fCurPtr = htonl(SSRC());
  fCurPtr += 4;

  // Allow for a special, payload-format-specific header following the
  // RTP header:
  fSpecialHeader = fCurPtr;
  fSpecialHeaderSize = specialHeaderSize();
  fCurPtr += fSpecialHeaderSize;
}

void DSPushRTPSink::processFrame(unsigned frameSize,
					   struct timeval presentationTime,
					   SampleProps* sProps) {

	unsigned overflowBytes = frameSize;
	unsigned frameBytes = 0;

	while (overflowBytes)
	{
		buildPacket();

		fPacketSize = fCurPtr - fPacket;

		if (fPacketSize + overflowBytes > maxPacketSize)
			frameBytes = maxPacketSize - fPacketSize;
		else
			frameBytes = overflowBytes;

		fCurPtr += frameBytes;

		// Here's where any payload format specific processing gets done:
		doSpecialFrameHandling(frameSize - overflowBytes, fSpecialHeader,
				   frameSize, presentationTime,
				   overflowBytes - frameBytes,
				   sProps);

		overflowBytes -= frameBytes;

		fPacketSize = fCurPtr - fPacket;

		sendPacket();

		fIsFirstPacket = False;
	}

	//Sleep(1);

  // Is there something to do after sending packets ?
  //((BasicTaskScheduler&)envir().taskScheduler()).handleAlarm();

}

void DSPushRTPSink::sendPacket() {

  // Send the packet:
//#define TEST_LOSS
#ifdef TEST_LOSS
  if ((our_random()%10) != 0) // simulate 10% packet loss #####
#endif
  fRTPInterface.sendPacket(fPacket, fPacketSize);
  ++fPacketCount;
  fTotalOctetCount += fPacketSize;
  fOctetCount +=
    fPacketSize - rtpHeaderSize /* for the RTP header */
    - fSpecialHeaderSize;

  ++fSeqNo; // for next time

  // Pointer to next packet
  fPacket += fPacketSize;
  // Room for RTP header
  fPacket -= rtpHeaderSize;

  // Fake delayed task to make SingleStep() responsive ...
  /*nextTask() = envir().taskScheduler().scheduleDelayedTask(0,
						(TaskFunc*)sendNext, this);*/

}

// The following is called after each packet sends:
void DSPushRTPSink::sendNext(int firstArg) {
  static int n = 0;
  DSPushRTPSink* sink = (DSPushRTPSink*)firstArg;
  //fprintf(stderr, "[%d] Send %s/%s packet\r\n", ++n, sink->sdpMediaType(), sink->rtpPayloadFormatName());
  //sink->buildAndSendPacket(False);
}


void DSPushRTPSink::ourHandleClosure(void* clientData) {
  DSPushRTPSink* sink = (DSPushRTPSink*)clientData;
  // There are no frames left, but we may have a partially built packet
  //  to send
  sink->sendPacket();
}