/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2002 Live Networks, Inc.  All rights reserved.
// RTP sink for H.263+ video (RFC 2429)
// Implementation

#include "MSVideoRTPSink.hh"

MSVideoRTPSink
::MSVideoRTPSink(UsageEnvironment& env, Groupsock* RTPgs,
				unsigned char rtpPayloadFormat,
				unsigned rtpTimestampFrequency,
				char const* rtpPayloadFormatName)
  //: MultiFramedRTPSink(env, RTPgs, rtpPayloadFormat, rtpTimestampFrequency, rtpPayloadFormatName),
  : DSPushRTPSink(env, RTPgs, rtpPayloadFormat, rtpTimestampFrequency, rtpPayloadFormatName),
    fpmt(NULL), fHeaderSize(0) {
}

MSVideoRTPSink::~MSVideoRTPSink() {

	if (fpmt)
	 delete [] fpmt;
}

MSVideoRTPSink*
MSVideoRTPSink::createNew(UsageEnvironment& env, Groupsock* RTPgs,
				unsigned char rtpPayloadFormat,
				unsigned rtpTimestampFrequency,
			    char const* rtpPayloadFormatName,
				AM_MEDIA_TYPE *pmt) {
  MSVideoRTPSink *sink = new MSVideoRTPSink(env, RTPgs, rtpPayloadFormat, rtpTimestampFrequency, rtpPayloadFormatName);
  if (sink != NULL)
  {
	sink->fHeaderSize = sizeof(AM_MEDIA_TYPE) - sizeof(BYTE*) + pmt->cbFormat + sizeof(SampleProps);
	sink->fpmt =(AM_MEDIA_TYPE*) new BYTE[sink->fHeaderSize - sizeof(SampleProps)];
	memcpy(sink->fpmt, pmt, sizeof(AM_MEDIA_TYPE) - sizeof(BYTE*));
    memcpy(&sink->fpmt->pbFormat, pmt->pbFormat, pmt->cbFormat);
  }
  return sink;
}

MSVideoRTPSink*
MSVideoRTPSink::createNew(UsageEnvironment& env, Groupsock* RTPgs,
						AM_MEDIA_TYPE *pmt) {
  unsigned rtpTimestampFrequency = (*(DWORD*)pmt == 0x73646976) ? 90000 : 8000; // 'vids' or 'auds' ?
  return createNew(env, RTPgs, 
	  96,
	  rtpTimestampFrequency,
	  "X-MS-DSHOW",
	  pmt);
}

Boolean MSVideoRTPSink
::frameCanAppearAfterPacketStart(unsigned char const* frameStart,
				 unsigned numBytesInFrame) const {
  // A packet can contain only one frame
  return False;
}

void MSVideoRTPSink
::doSpecialFrameHandling(unsigned fragmentationOffset,
			 unsigned char* frameStart,
			 unsigned numBytesInFrame,
			 struct timeval frameTimestamp,
			 unsigned numRemainingBytes,
			 SampleProps* sProps) {
  if (fragmentationOffset == 0) {
    /*if (numBytesInFrame < fHeaderSize) {
      fprintf(stderr, "MSVideoRTPSink::doSpecialFrameHandling(): bad frame size %d\n", numBytesInFrame);
      return;
    }*/

	setSpecialHeaderBytes((unsigned char*)fpmt, fHeaderSize - sizeof(SampleProps));
	setSpecialHeaderBytes((unsigned char*)sProps, sizeof(SampleProps), fHeaderSize - sizeof(SampleProps));

  }

  if (numRemainingBytes == 0) {
    // This packet contains the last (or only) fragment of the frame.
    // Set the RTP 'M' ('marker') bit:
    setMarkerBit();
  }

  // Also set the RTP timestamp:
  setTimestamp(frameTimestamp);
}

unsigned MSVideoRTPSink::specialHeaderSize() const {
	return isFirstPacket() ? fHeaderSize : 0;
}

char const* MSVideoRTPSink::sdpMediaType() const {
  return (*(DWORD*)fpmt == 0x73646976) ? "video" : "audio"; // 'vids' ?
}
