/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2002 Live Networks, Inc.  All rights reserved.
// An abstraction of a network interface used for RTP (or RTCP).
// (This allows the RTP-over-TCP hack (RFC 2236, section 10.12) to
// be implemented transparently.)
// Implementation

#include "RTPInterface.hh"
#include <GroupsockHelper.hh>
#include <stdio.h>
#if defined(__WIN32__) || defined(_WIN32)
#else
#include <sys/socket.h>
#include <unistd.h>
#endif

////////// Helper Functions - Definition //////////

// Helper routines and data structures, used to implement
// sending/receiving RTP/RTCP over a TCP socket:

static void sendRTPOverTCP(unsigned char* packet, unsigned packetSize,
			   int socketNum, unsigned char streamChannelId);

// Reading RTP-over-TCP is implemented using two levels of hash tables
// The top-level hash table maps a TCP socket numbers to a
// "SocketDescriptor" that contains a hash table for each of the
// sub-channels that are reading from this socket.

static HashTable* socketHashTable = NULL;

class SocketDescriptor {
public:
  SocketDescriptor(UsageEnvironment& env, int socketNum);
  virtual ~SocketDescriptor();

  void registerRTPInterface(unsigned char streamChannelId,
			    RTPInterface* rtpInterface);
  RTPInterface* lookupRTPInterface(unsigned char streamChannelId);
  void deregisterRTPInterface(unsigned char streamChannelId);

private:
  static void tcpReadHandler(int socketNum, int mask);

private:
  UsageEnvironment& fEnv;
  int fOurSocketNum;
  HashTable* fSubChannelHashTable;
};

static SocketDescriptor* lookupSocketDescriptor(int sockNum) {
  return (SocketDescriptor*)(socketHashTable->Lookup((char const*)sockNum));
}


////////// RTPInterface - Implementation //////////

RTPInterface::RTPInterface(Medium* owner, Groupsock* gs)
  : fOwner(owner), fGS(gs), fStreamSocketNum(-1),
    fNextTCPReadSize(0), fHandlerProc(NULL) {
}

RTPInterface::~RTPInterface() {}

void RTPInterface::setStreamSocket(int sockNum,
				   unsigned char streamChannelId) {
  fStreamSocketNum = sockNum;
  fStreamChannelId = streamChannelId;
}

void RTPInterface::sendPacket(unsigned char* packet, unsigned packetSize) {
  if (fStreamSocketNum < 0) {
    // Normal case: Send as a UDP packet:
    fGS->output(envir(), fGS->ttl(), packet, packetSize);
  } else {
    // Send RTP over TCP:
    sendRTPOverTCP(packet, packetSize, fStreamSocketNum, fStreamChannelId);
  }
}

void RTPInterface
::startNetworkReading(TaskScheduler::BackgroundHandlerProc* handlerProc) {
  if (fStreamSocketNum < 0) {
    // Normal case: Arrange to read UDP packets:
    envir().taskScheduler().
      turnOnBackgroundReadHandling(fGS->socketNum(), handlerProc, fOwner);
  } else {
    // Receive RTP over TCP.
    fHandlerProc = handlerProc;

    // Get a socket descriptor for "fStreamSockNum":
    if (socketHashTable == NULL) {
      socketHashTable = HashTable::create(ONE_WORD_HASH_KEYS);
    }
    SocketDescriptor* socketDescriptor
      = lookupSocketDescriptor(fStreamSocketNum);
    if (socketDescriptor == NULL) {
      socketDescriptor = new SocketDescriptor(envir(), fStreamSocketNum);
      socketHashTable->Add((char const*)fStreamSocketNum, socketDescriptor);
    }

    // Tell it about our subChannel:
    socketDescriptor->registerRTPInterface(fStreamChannelId, this);
  }
}

Boolean RTPInterface::handleRead(unsigned char* buffer,
				 unsigned bufferMaxSize,
				 unsigned& bytesRead,
				 struct sockaddr_in& fromAddress) {
  if (fStreamSocketNum < 0) {
    // Normal case: read from the (datagram) 'groupsock':
    return fGS->handleRead(buffer, bufferMaxSize, bytesRead, fromAddress);
  } else {
    // Read from the TCP connection:
    bytesRead = 0;
    unsigned totBytesToRead = fNextTCPReadSize; //fNextTCPReadSize = 0;
    if (totBytesToRead > bufferMaxSize) totBytesToRead = bufferMaxSize; 
    unsigned curBytesToRead = totBytesToRead;
    unsigned curBytesRead;
    while ((curBytesRead = readSocket(envir(), fStreamSocketNum,
				      &buffer[bytesRead], curBytesToRead,
				      fromAddress)) > 0) {
      bytesRead += curBytesRead;
      if (bytesRead >= totBytesToRead) break;
      curBytesToRead -= curBytesRead;
    }

	if (bytesRead != fNextTCPReadSize)
		fprintf(stderr, "handleRead: failed: %d/%d bytes read\n", bytesRead, fNextTCPReadSize);
	fNextTCPReadSize = 0;

    if (curBytesRead <= 0) {
      bytesRead = 0;
      return False;
    }
    return True;
  }
}

void RTPInterface::stopNetworkReading() {
  if (fStreamSocketNum < 0) {
    // Normal case
    envir().taskScheduler().
      turnOffBackgroundReadHandling(fGS->socketNum());
  } else {
    if (socketHashTable == NULL) return;

    SocketDescriptor* socketDescriptor
      = lookupSocketDescriptor(fStreamSocketNum);
    if (socketDescriptor == NULL) return;

    socketDescriptor->deregisterRTPInterface(fStreamChannelId);
  }
}


////////// Helper Functions - Implementation /////////

void sendRTPOverTCP(unsigned char* packet, unsigned packetSize,
                    int socketNum, unsigned char streamChannelId) {
#ifdef DEBUG_SENDING
  fprintf(stderr, "sendRTPOverTCP: %d bytes over channel %d (socket %d)\n",
	  packetSize, streamChannelId, socketNum); fflush(stderr);
#endif
  // Send RTP over TCP, using the encoding defined in
  // RFC 2326, section 10.12:
  do {
    char const dollar = '$';
    //if (send(socketNum, &dollar, 1, 0) < 1) break;

    //if (send(socketNum, (char*)&streamChannelId, 1, 0) < 1) break;

    char netPacketSize[2];
    netPacketSize[0] = (char) ((packetSize&0xFF00)>>8);
    netPacketSize[1] = (char) (packetSize&0xFF);
    //if (send(socketNum, netPacketSize, 2, 0) < 2) break;

	char Header[4];
	Header[0] = dollar;
	Header[1] = streamChannelId;
	Header[2] = netPacketSize[0];
	Header[3] = netPacketSize[1];
    if (send(socketNum, Header, 4, 0) < 4) break;

    if (send(socketNum, (char*)packet, packetSize, 0) < packetSize) break;
#ifdef DEBUG_SENDING
    fprintf(stderr, "sendRTPOverTCP: completed\n"); fflush(stderr);
#endif

    return;
  } while (0);
#define DEBUG_SENDING
#ifdef DEBUG_SENDING
  fprintf(stderr, "sendRTPOverTCP: failed: %d\n",
#if defined(__WIN32__) || defined(_WIN32)
          WSAGetLastError()
#else
          errno
#endif
          ); fflush(stderr);
#endif
}

SocketDescriptor::SocketDescriptor(UsageEnvironment& env, int socketNum)
  : fEnv(env), fOurSocketNum(socketNum),
    fSubChannelHashTable(HashTable::create(ONE_WORD_HASH_KEYS)) {
}

SocketDescriptor::~SocketDescriptor() {
  delete fSubChannelHashTable;
}

void SocketDescriptor::registerRTPInterface(unsigned char streamChannelId,
					    RTPInterface* rtpInterface) {
  Boolean isFirstRegistration = fSubChannelHashTable->IsEmpty();
  fSubChannelHashTable->Add((char const*)streamChannelId, rtpInterface);

  if (isFirstRegistration) {
    // Arrange to handle reads on this TCP socket:
    TaskScheduler::BackgroundHandlerProc* handler
      = (TaskScheduler::BackgroundHandlerProc*)&tcpReadHandler;
    fEnv.taskScheduler().
      turnOnBackgroundReadHandling(fOurSocketNum,
				   handler, (void*)fOurSocketNum);
  }
}

RTPInterface* SocketDescriptor
::lookupRTPInterface(unsigned char streamChannelId) {
  return (RTPInterface*)(fSubChannelHashTable
			 ->Lookup((char const*)streamChannelId));
}

void SocketDescriptor
::deregisterRTPInterface(unsigned char streamChannelId) {
  fSubChannelHashTable->Remove((char const*)streamChannelId);

  if (fSubChannelHashTable->IsEmpty()) {
    fEnv.taskScheduler().turnOffBackgroundReadHandling(fOurSocketNum);
  }
}

void SocketDescriptor::tcpReadHandler(int socketNum, int mask) {
  SocketDescriptor* socketDescriptor
    = lookupSocketDescriptor(socketNum);  
  
  if (socketDescriptor == 0)
	  return;

  UsageEnvironment& env = socketDescriptor->fEnv; // abbrev
  unsigned char c = '\0';

  do {

    // Begin by reading and discarding any characters that aren't '$'.
    // Any such characters are probably regular RTSP responses or
    // commands from the server.  At present, we can't do anything with
    // these, because we have taken complete control of reading this socket.
    // (Later, fix) #####
    struct sockaddr_in fromAddress;
    while (readSocket(env, socketNum, &c, 1, fromAddress) != 1);

    if (c != '$') 
	{
		char Err[256];
		sprintf(Err, "%c (0x%.02X) is not $", c, c);
		env.setResultMsg(Err);
		break;
	}

    // The next byte is the stream channel id:
    unsigned char streamChannelId;
    while (readSocket(env, socketNum, &streamChannelId, 1, fromAddress)	!= 1);
	
    RTPInterface* rtpInterface
      = socketDescriptor->lookupRTPInterface(streamChannelId);
    if (rtpInterface == NULL) break; // we're not interested in this channel

    // The next two bytes are the RTP or RTCP packet size (in network order)
    unsigned char size_hi;
    while (readSocket(env, socketNum, &size_hi, 1, fromAddress)	!= 1);

    unsigned char size_lo;
    while (readSocket(env, socketNum, &size_lo, 1, fromAddress)	!= 1);

	rtpInterface->fNextTCPReadSize = (unsigned short)size_hi << 8 | size_lo;

    /*unsigned short size;
    if (readSocket(env, socketNum, (unsigned char*)&size, 2,
		   fromAddress) != 2) break;
    rtpInterface->fNextTCPReadSize = ntohs(size);*/

    // Now that we have the data set up, call this subchannel's
    // read handler:
    if (rtpInterface->fHandlerProc != NULL) {
      rtpInterface->fHandlerProc(rtpInterface->fOwner, mask);
    }

    return;
  } while (0);
#define DEBUG_RECEVING
#ifdef DEBUG_RECEVING
  if (c == '$')
	fprintf(stderr, "tcpReadHandler: failed: %s\n", env.getResultMsg());
#endif
}
